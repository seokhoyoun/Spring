package org.kh.first.test.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.kh.first.test.model.vo.Sample;
import org.kh.first.test.model.vo.User;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class TestController {
	//testAjaxPage.jsp 내보내기용
	@RequestMapping("moveAjax.do")
	public String moveAjaxPage() {
		return "test/testAjaxPage";
	}
	
	// AJAX TEST METHOD =================================================
	@RequestMapping(value = "test1.do", method= RequestMethod.POST)
	public void test1Method(Sample sample, HttpServletResponse response) throws IOException {
		System.out.println(sample);
		response.setContentType("text/html; charset=utf-8");
		PrintWriter out = response.getWriter();
		if(sample.getName().equals("박혁거세")) 
			out.append("ok");
		else 
			out.append("fail");
		out.flush();
		out.close();
		}
	@RequestMapping(value="test2.do", method = RequestMethod.POST)
	@ResponseBody // 리턴하는 json 문자열을 response 객체에 담아서 보내라는 의미의 어노테이션
	public String test2Method(HttpServletResponse response) throws UnsupportedEncodingException {
		response.setContentType("application/json; charset=utf-8");
		JSONObject job = new JSONObject();
		job.put("no", 123);
		job.put("title", URLEncoder.encode("ajax로 json 리턴테스트", "utf-8"));
		job.put("writer", "user01");
		job.put("content", URLEncoder.encode("컨트롤러에서 json 객체를 ajax로 보냈습니다", "utf-8"));
		
		return job.toJSONString();
	}
	@RequestMapping(value="test3.do", method= RequestMethod.POST)
	public void test3Method(HttpServletResponse response) throws IOException {
		List<User> list = new ArrayList<>();
		
		list.add(new User("u11","p12","홍길동",25,"sadasd@sad.com","011-123-2333"));
		list.add(new User("u22","p22","김길동",21,"sadasd@sad.com","011-123-2333"));
		list.add(new User("u33","p33","박길동",22,"sadasd@sad.com","011-123-2333"));
		list.add(new User("u44","p44","오길동",27,"sadasd@sad.com","011-123-2333"));
		list.add(new User("u55","p55","천길동",29,"sadasd@sad.com","011-123-2333"));
		list.add(new User("u66","p66","아길동",20,"sadasd@sad.com","011-123-2333"));
		
		// 전송용 객체 생성
		JSONObject sendObj = new JSONObject();
		
		JSONArray jarr = new JSONArray();
		
		// list를 jarr에 복사
		for(User user : list) {
			// user 객체 저장용 json 객체 생성
			JSONObject juser = new JSONObject();
			juser.put("userid", user.getUserid());
			juser.put("userpwd", user.getUserpwd());
			juser.put("username", user.getUsername());
			juser.put("age", user.getAge());
			juser.put("email", user.getEmail());
			juser.put("phone", user.getPhone());
			
			// jarr에 juser 저장
			jarr.add(juser);
		}
		sendObj.put("list", jarr);
		
		response.setContentType("application/json; charset=utf-8");
		PrintWriter out = response.getWriter();
		out.print(sendObj.toJSONString());
		out.flush();
		out.close();
	}
	@RequestMapping(value="test4.do", method = RequestMethod.POST)
	public ModelAndView testMethod(ModelAndView mv) throws UnsupportedEncodingException {
		// Map을 ModelAndView에 담아서 JsonView로 보냄
		Sample samp = new Sample("이율곡", 55);
		samp.setName(URLEncoder.encode(samp.getName(), "utf-8"));
		
		Map<String, Sample> map = new HashMap<>();
		map.put("samp", samp);
		
		mv.addObject(map);
		// 뷰지정 : 등록된 JsonView의 아이디를 뷰이름으로 지정함
		mv.setViewName("jsonView");
		
		
		return mv; // 뷰 리졸버가 전달되고 요청한 ajax는 json 객체를 받음
		
	}
	@RequestMapping(value="test5.do", method=RequestMethod.POST)
	public ResponseEntity<String> test5Method(@RequestBody String param) throws ParseException{
		// request body에 저장되어서 전송 온 json 문자열을 param에 저장함.
		// 전송온 json 문자열을 json 객체로 바꿈
		JSONParser jparser = new JSONParser();
		JSONObject job = (JSONObject)jparser.parse(param);
		
		String name = job.get("name").toString();
		int age = ((Long)job.get("age")).intValue();
		
		System.out.println(name);
		System.out.println(age);
		
		return new ResponseEntity<String>("success", HttpStatus.OK);
	}
	@RequestMapping(value="test6.do", method=RequestMethod.POST)
	   public ResponseEntity<String> test6Method(@RequestBody String param) throws ParseException {//POST방식은 @RequestBody
	      //request body에 저장되어 전송 온 json 배열 문자열을 param 에 저장함
	      
	      //전송 온 json 배열 문자열을 json 배열객체로 바꿈
	      JSONParser jparser = new JSONParser();
	      JSONArray jarr = (JSONArray)jparser.parse(param);
	      System.out.println("jarr size : " + jarr.size());
	      
	      for(int i = 0; i< jarr.size(); i++) {
	         JSONObject job = (JSONObject) jarr.get(i);
	         Sample samp = new Sample();
	         samp.setName((String)job.get("name"));
	         samp.setAge(((Long)job.get("age")).intValue());
	         
	         System.out.println(samp);
	      }
	      
	      //정상 완료되었음을 클라이언트로 보냄
	      return new ResponseEntity<String>("success", HttpStatus.OK);
	   }
}
